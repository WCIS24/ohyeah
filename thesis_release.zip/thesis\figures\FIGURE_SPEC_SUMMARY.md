# FIGURE_SPEC_SUMMARY

日期：2026-02-01

扫描对象：
- my-thesis/仓库地图.pdf
- my-thesis/金融AI选题评价.pdf

结果：
- 两份 PDF 未包含论文排版规范（未出现图题/表题/字体/字号等关键词）。
- 仓库内未发现“本科论文格式 PDF”或其他图表规范文件。

结论：
- 本次绘图先严格遵守用户给定硬性约束（caption 位置、字体要求、线型/marker、色盲友好等）。
- 待你提供论文格式 PDF 后，可更新本文件并同步调整 mplstyle / LaTeX 细节。
